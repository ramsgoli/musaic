"""w0401 dependency
"""
# pylint: disable=print-statement, no-absolute-import
from __future__ import print_function

from . import func_w0401

if func_w0401:
    print(input)
