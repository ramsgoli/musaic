# pylint: disable=invalid-name, missing-docstring
# pylint: disable=unbalanced-tuple-unpacking
n = 42
