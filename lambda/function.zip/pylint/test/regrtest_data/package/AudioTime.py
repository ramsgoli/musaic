"""test preceeded by the AudioTime class in __init__.py"""

__revision__ = 0
